def maximum(a, b):
	return a if a > b else b