
from django.contrib import admin
from django.urls import path
from app import views
# from .views import convert_code

urlpatterns = [
    path('', views.index, name='index'),
    path('registration', views.registration, name='registration'),
    path('log_in', views.log_in, name='log_in'),
    path('dashboard', views.dashboard, name='dashboard'),
    # path('convert-code', views.convert_code, name='convert_code'),
    path('log_out', views.log_out, name='log_out'),
        path('download/', views.download_code, name='download_code'), 
]

