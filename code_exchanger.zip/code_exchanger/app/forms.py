from django import forms

class CodeConversionForm(forms.Form):
    LANG_CHOICES = [
        ('python', 'Python'),
        ('java', 'Java'),
        ('c', 'C'),
    ]

    source_language = forms.ChoiceField(choices=LANG_CHOICES, label='Select Input Language')
    target_language = forms.ChoiceField(choices=LANG_CHOICES, label='Select Output Language')
    source_code = forms.CharField(widget=forms.Textarea(attrs={'placeholder': 'Type your code here...'}), label='Enter Your Code')
