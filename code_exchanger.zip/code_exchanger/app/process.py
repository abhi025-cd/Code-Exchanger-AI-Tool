import pathlib
import textwrap

import google.generativeai as genai

# Used to securely store your API Key
# from google.colab import userdata

from IPython.display import display
from IPython.display import Markdown

import os 
os.environ['GOOGLE_API_KEY'] = "AIzaSyBocedCCWQdbtOvjvkQzQSMpNTg1s35aws"

genai.configure(api_key=os.environ['GOOGLE_API_KEY'])


def code_exchange(source_code, target_language):
    # Add your code here to modify the message as per requirement.
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(source_code + f"convert the complete code in {target_language}. Give me a complete line by line code")
    #response2 = model.generate_content("Give me a top 10 links related to " + message)
    return response.text