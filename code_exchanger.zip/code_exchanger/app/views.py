from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import cache_control
from django.http import HttpResponse
from .forms import CodeConversionForm
from .process import code_exchange
from .auth import authentication

def index(request):
    return render(request, 'index.html')

def registration(request):
    if request.method == "POST":
        first_name = request.POST['fname']
        last_name = request.POST['lname']
        email = request.POST['email']
        password = request.POST['password']
        repassword = request.POST['repassword']

        verify = authentication(first_name, last_name, password, repassword)
        if verify == "success":
            user = User.objects.create_user(username=email, email=email, password=password)
            user.first_name = first_name
            user.last_name = last_name
            user.save()
            messages.success(request, "Your Account has been Created.")
            return redirect("log_in")
        else:
            messages.error(request, verify)
            return redirect("registration")
    return render(request, "registration.html")

def log_in(request):
    if request.method == "POST":
        u_name = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=u_name, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Log In Successful...!")
            return redirect("dashboard")
        else:
            messages.error(request, "Invalid User...!")
            return redirect("log_in")
    return render(request, "log_in.html")

@login_required(login_url="log_in")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def dashboard(request):
    if request.method == 'GET':
        # Clear the session data on page load (GET request)
        if 'converted_code' in request.session:
            del request.session['converted_code']
        if 'target_language' in request.session:
            del request.session['target_language']

    form = CodeConversionForm(request.POST or None)
    context = {
        'fname': request.user.first_name,
        'form': form,
        'converted_code': request.session.get('converted_code', '')
    }

    if request.method == 'POST' and form.is_valid():
        source_language = form.cleaned_data['source_language']
        target_language = form.cleaned_data['target_language']
        source_code = form.cleaned_data['source_code']
        converted_code = code_exchange(source_code, target_language)
        
        request.session['converted_code'] = converted_code
        request.session['target_language'] = target_language
        context['converted_code'] = converted_code

    return render(request, 'dashboard.html', context)

@login_required(login_url="log_in")
def download_code(request):
    converted_code = request.session.get('converted_code', '')
    target_language = request.session.get('target_language', '')

    language_extensions = {
        'python': 'py',
        'java': 'java',
        'c': 'cpp'
    }

    file_extension = language_extensions.get(target_language, '')

    if file_extension:
        filename = f'converted_code.{file_extension}'
    else:
        filename = 'converted_code'

    response = HttpResponse(converted_code, content_type='text/plain')
    response['Content-Disposition'] = f'attachment; filename={filename}'
    
    return response

@login_required(login_url="log_in")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def log_out(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect("/")
